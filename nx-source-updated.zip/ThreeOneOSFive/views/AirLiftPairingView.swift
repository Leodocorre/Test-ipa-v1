import SwiftUI

struct AirLiftPairingView: View {
    @ObservedObject var pairing: AirLiftPairingController

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()

            VStack(spacing: 22) {
                Image(systemName: "iphone.and.arrow.forward")
                    .font(.system(size: 52, weight: .semibold))
                    .foregroundStyle(.white)

                Text("Conexão necessária")
                    .font(.title2.weight(.bold))
                    .foregroundStyle(.white)

                Text("Esta versão do iOS precisa da conexão primária antes de abrir os patches.")
                    .font(.body)
                    .foregroundStyle(.white.opacity(0.72))
                    .multilineTextAlignment(.center)

                if let pin = pairing.pin {
                    VStack(spacing: 8) {
                        Text("Código de pareamento")
                            .font(.caption.weight(.semibold))
                            .foregroundStyle(.white.opacity(0.58))
                        Text(pin)
                            .font(.system(size: 38, weight: .bold, design: .monospaced))
                            .tracking(5)
                            .foregroundStyle(.white)
                            .padding(.horizontal, 24)
                            .padding(.vertical, 14)
                            .background(
                                RoundedRectangle(cornerRadius: 14, style: .continuous)
                                    .fill(Color.white.opacity(0.1))
                            )
                    }
                }

                Text(pairing.statusText)
                    .font(.subheadline.weight(.medium))
                    .foregroundStyle(pairing.state.isReady ? .green : .white.opacity(0.7))
                    .multilineTextAlignment(.center)

                if pairing.notificationPermissionDenied {
                    Text("As notificações estão desativadas. O código continua visível nesta tela.")
                        .font(.caption)
                        .foregroundStyle(.yellow.opacity(0.9))
                        .multilineTextAlignment(.center)
                }

                if pairing.state.isReady {
                    Text("Conexão confirmada. Abrindo patches…")
                        .font(.footnote)
                        .foregroundStyle(.green)
                } else {
                    Button {
                        Task { await pairing.beginPairing() }
                    } label: {
                        Text(pairing.pin == nil ? "Iniciar pareamento" : "Enviar código novamente")
                            .font(.body.weight(.semibold))
                            .foregroundStyle(.black)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 13)
                            .background(Color.white, in: RoundedRectangle(cornerRadius: 12, style: .continuous))
                    }
                    .buttonStyle(.plain)
                }
            }
            .padding(.horizontal, 28)
            .frame(maxWidth: 420)
        }
        .task {
            if pairing.pin == nil {
                await pairing.beginPairing()
            }
        }
    }
}

#if DEBUG
struct AirLiftPairingView_Previews: PreviewProvider {
    static var previews: some View {
        AirLiftPairingView(pairing: AirLiftPairingController.shared)
            .preferredColorScheme(.dark)
    }
}
#endif
