import SwiftUI

struct AirLiftPairingView: View {
    @ObservedObject var pairing: AirLiftPairingController

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()

            ScrollView {
                VStack(spacing: 18) {
                    Image(systemName: "network.badge.shield.half.filled")
                        .font(.system(size: 48, weight: .semibold))
                        .foregroundStyle(.white)
                        .padding(.top, 28)

                    Text("Conexão necessária")
                        .font(.title2.weight(.bold))
                        .foregroundStyle(.white)

                    Text("Este iOS precisa do fluxo AirLift antes de abrir os patches. Siga as três etapas abaixo.")
                        .font(.body)
                        .foregroundStyle(.white.opacity(0.72))
                        .multilineTextAlignment(.center)

                    stepCard(
                        number: "1",
                        title: "Ative o Developer Mode",
                        message: "Abra Ajustes, entre em Privacidade e Segurança > Developer Mode e confirme. Depois volte para este app.",
                        actionTitle: "Abrir Ajustes",
                        action: pairing.openDeveloperMode
                    )

                    stepCard(
                        number: "2",
                        title: "Faça o pareamento",
                        message: "Inicie o pareamento para gerar o código. O pareamento só é concluído depois de uma sessão real autenticada com o dispositivo.",
                        actionTitle: pairing.pin == nil ? "Gerar código" : "Gerar novo código",
                        action: { Task { await pairing.beginPairing() } }
                    )

                    if let pin = pairing.pin {
                        VStack(spacing: 10) {
                            Text("Código de pareamento")
                                .font(.caption.weight(.semibold))
                                .foregroundStyle(.white.opacity(0.58))
                            Text(pin)
                                .font(.system(size: 36, weight: .bold, design: .monospaced))
                                .tracking(5)
                                .foregroundStyle(.white)
                            Button("Copiar código") { pairing.copyPIN() }
                                .font(.caption.weight(.semibold))
                                .foregroundStyle(.white.opacity(0.8))
                        }
                        .padding(.vertical, 14)
                        .frame(maxWidth: .infinity)
                        .background(RoundedRectangle(cornerRadius: 14).fill(Color.white.opacity(0.1)))
                    }

                    stepCard(
                        number: "3",
                        title: "Instale e conecte o LocalDevVPN",
                        message: "O app de referência usa o LocalDevVPN como ponte. Instale-o pela App Store, permita a configuração VPN e retorne para concluir o transporte.",
                        actionTitle: "Abrir LocalDevVPN na App Store",
                        action: pairing.openLocalDevVPN
                    )

                    Text(pairing.statusText)
                        .font(.subheadline.weight(.medium))
                        .foregroundStyle(pairing.state.isReady ? .green : .white.opacity(0.7))
                        .multilineTextAlignment(.center)

                    if pairing.tunnelCallbackReceived {
                        Label("LocalDevVPN retornou para a IPA", systemImage: "checkmark.circle.fill")
                            .font(.footnote.weight(.semibold))
                            .foregroundStyle(.green)
                        Text("O retorno confirma apenas que o LocalDevVPN foi aberto. O pareamento AirLift/RSD ainda precisa confirmar o transporte antes de liberar os patches.")
                            .font(.caption)
                            .foregroundStyle(.white.opacity(0.58))
                            .multilineTextAlignment(.center)
                    }

                    if pairing.notificationPermissionDenied {
                        Text("As notificações estão desativadas. O código continua disponível nesta tela.")
                            .font(.caption)
                            .foregroundStyle(.yellow.opacity(0.9))
                            .multilineTextAlignment(.center)
                    }

                    if pairing.state.isReady {
                        Text("Conexão confirmada. Abrindo patches…")
                            .font(.footnote)
                            .foregroundStyle(.green)
                    } else {
                        Text("Depois de conectar o LocalDevVPN, volte para cá. Os patches permanecem bloqueados até a verificação real do transporte.")
                            .font(.footnote)
                            .foregroundStyle(.white.opacity(0.52))
                            .multilineTextAlignment(.center)
                    }
                }
                .padding(.horizontal, 22)
                .padding(.bottom, 28)
                .frame(maxWidth: 480)
                .frame(maxWidth: .infinity)
            }
        }
        .task {
            if pairing.pin == nil { await pairing.beginPairing() }
        }
    }

    @ViewBuilder
    private func stepCard(number: String, title: String, message: String, actionTitle: String, action: @escaping () -> Void) -> some View {
        VStack(alignment: .leading, spacing: 9) {
            HStack(alignment: .top, spacing: 11) {
                Text(number)
                    .font(.headline.weight(.bold))
                    .foregroundStyle(.black)
                    .frame(width: 28, height: 28)
                    .background(Circle().fill(Color.white))
                VStack(alignment: .leading, spacing: 4) {
                    Text(title)
                        .font(.headline.weight(.semibold))
                        .foregroundStyle(.white)
                    Text(message)
                        .font(.caption)
                        .foregroundStyle(.white.opacity(0.65))
                        .fixedSize(horizontal: false, vertical: true)
                }
            }
            Button(actionTitle, action: action)
                .font(.subheadline.weight(.semibold))
                .foregroundStyle(.black)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 11)
                .background(Color.white, in: RoundedRectangle(cornerRadius: 11, style: .continuous))
                .buttonStyle(.plain)
        }
        .padding(14)
        .background(RoundedRectangle(cornerRadius: 15, style: .continuous).fill(Color.white.opacity(0.075)))
    }
}

#if DEBUG
struct AirLiftPairingView_Previews: PreviewProvider {
    static var previews: some View {
        AirLiftPairingView(pairing: AirLiftPairingController.shared)
            .preferredColorScheme(.dark)
    }
}
#endif
