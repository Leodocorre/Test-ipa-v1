import Foundation
import UserNotifications
import UIKit

/// Controls the user-facing AirLift pairing state.
///
/// The pairing transport must mark the session ready only after a real,
/// authenticated device session has been established. Generating a PIN or
/// posting a notification never grants patch access by itself.
@MainActor
final class AirLiftPairingController: ObservableObject {
    static let shared = AirLiftPairingController()

    enum State: Equatable {
        case idle
        case requestingNotificationPermission
        case waitingForConfirmation
        case ready
        case failed(String)

        var isReady: Bool {
            if case .ready = self { return true }
            return false
        }
    }

    @Published private(set) var state: State = .idle
    @Published private(set) var pin: String?
    @Published private(set) var notificationPermissionDenied = false
    @Published private(set) var setupStep: SetupStep = .developerMode
    @Published private(set) var tunnelCallbackReceived = false

    private let notificationIdentifier = "3105-airlift-pairing-pin"
    private var pinIssuedAt: Date?
    private let pinLifetime: TimeInterval = 180
    static let localDevVPNURL = URL(string: "https://apps.apple.com/us/app/localdevvpn/id6755608044")!
    static let callbackScheme = "nxff4x"

    enum SetupStep: Int, CaseIterable {
        case developerMode
        case pairing
        case tunnel

        var title: String {
            switch self {
            case .developerMode: return "Ative o Developer Mode"
            case .pairing: return "Faça o pareamento"
            case .tunnel: return "Conecte o LocalDevVPN"
            }
        }
    }

    var statusText: String {
        switch state {
        case .idle: return "Pairing não iniciado"
        case .requestingNotificationPermission: return "Solicitando permissão de notificação…"
        case .waitingForConfirmation: return "Aguardando confirmação do dispositivo"
        case .ready: return "Ready to use"
        case .failed(let message): return message
        }
    }

    func beginPairing() async {
        guard !state.isReady else { return }

        setupStep = .pairing
        state = .requestingNotificationPermission
        let settings = await requestNotificationPermissionIfNeeded()
        notificationPermissionDenied = settings.authorizationStatus == .denied

        let newPIN = String(format: "%06d", Int.random(in: 0...999_999))
        pin = newPIN
        pinIssuedAt = Date()
        state = .waitingForConfirmation
        await postPINNotification(newPIN, settings: settings)
    }

    func cancel() {
        pin = nil
        pinIssuedAt = nil
        setupStep = .developerMode
        state = .idle
        UNUserNotificationCenter.current().removeDeliveredNotifications(withIdentifiers: [notificationIdentifier])
        UNUserNotificationCenter.current().removePendingNotificationRequests(withIdentifiers: [notificationIdentifier])
    }

    /// Called only by the real authenticated transport after pair-verify and
    /// the required service handshake have completed successfully.
    func markTransportReady() {
        guard isPINCurrent else { return }
        state = .ready
    }

    func markTransportFailed(_ message: String) {
        state = .failed(message)
    }

    func openDeveloperMode() {
        setupStep = .developerMode
        let candidates = [
            "App-Prefs:root=Privacy&path=DEVELOPER_MODE",
            "App-Prefs:root=General"
        ]
        openFirstAvailable(candidates)
    }

    func openLocalDevVPN() {
        setupStep = .tunnel
        let callback = Self.callbackScheme.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? Self.callbackScheme
        if let enableURL = URL(string: "localdevvpn://enable?scheme=\(callback)") {
            UIApplication.shared.open(enableURL) { [weak self] opened in
                guard !opened else { return }
                self?.openLocalDevVPNStore()
            }
        } else {
            openLocalDevVPNStore()
        }
    }

    private func openLocalDevVPNStore() {
        UIApplication.shared.open(Self.localDevVPNURL)
    }

    func handleCallback(_ url: URL) {
        guard url.scheme?.lowercased() == Self.callbackScheme else { return }
        tunnelCallbackReceived = true
        setupStep = .tunnel
        state = .waitingForConfirmation
    }

    func copyPIN() {
        guard let pin else { return }
        UIPasteboard.general.string = pin
    }

    func returnToPairing() {
        setupStep = .pairing
    }

    private func openFirstAvailable(_ values: [String]) {
        guard let raw = values.first, let url = URL(string: raw) else { return }
        UIApplication.shared.open(url) { [weak self] success in
            guard !success, values.count > 1 else { return }
            self?.openFirstAvailable(Array(values.dropFirst()))
        }
    }

    private var isPINCurrent: Bool {
        guard let pinIssuedAt else { return false }
        return Date().timeIntervalSince(pinIssuedAt) < pinLifetime
    }

    private func requestNotificationPermissionIfNeeded() async -> UNNotificationSettings {
        let center = UNUserNotificationCenter.current()
        let current = await center.notificationSettings()
        guard current.authorizationStatus == .notDetermined else { return current }
        _ = try? await center.requestAuthorization(options: [.alert, .sound, .badge])
        return await center.notificationSettings()
    }

    private func postPINNotification(_ pin: String, settings: UNNotificationSettings) async {
        guard settings.authorizationStatus == .authorized || settings.authorizationStatus == .provisional else {
            return
        }

        let content = UNMutableNotificationContent()
        content.title = "3105 AirLift Pairing"
        content.body = "Código de pareamento: \(pin)"
        content.sound = .default
        content.userInfo = ["type": "airlift-pairing", "pin": pin]

        let request = UNNotificationRequest(
            identifier: notificationIdentifier,
            content: content,
            trigger: nil
        )
        try? await UNUserNotificationCenter.current().add(request)
    }
}
