import Foundation
import UserNotifications

/// Controls the user-facing AirLift pairing state.
///
/// The pairing transport must mark the session ready only after a real,
/// authenticated device session has been established. Generating a PIN or
/// posting a notification never grants patch access by itself.
@MainActor
final class AirLiftPairingController: ObservableObject {
    static let shared = AirLiftPairingController()

    enum State: Equatable {
        case idle
        case requestingNotificationPermission
        case waitingForConfirmation
        case ready
        case failed(String)

        var isReady: Bool {
            if case .ready = self { return true }
            return false
        }
    }

    @Published private(set) var state: State = .idle
    @Published private(set) var pin: String?
    @Published private(set) var notificationPermissionDenied = false

    private let notificationIdentifier = "3105-airlift-pairing-pin"
    private var pinIssuedAt: Date?
    private let pinLifetime: TimeInterval = 180

    var statusText: String {
        switch state {
        case .idle: return "Pairing não iniciado"
        case .requestingNotificationPermission: return "Solicitando permissão de notificação…"
        case .waitingForConfirmation: return "Aguardando confirmação do dispositivo"
        case .ready: return "Ready to use"
        case .failed(let message): return message
        }
    }

    func beginPairing() async {
        guard !state.isReady else { return }

        state = .requestingNotificationPermission
        let settings = await requestNotificationPermissionIfNeeded()
        notificationPermissionDenied = settings.authorizationStatus == .denied

        let newPIN = String(format: "%06d", Int.random(in: 0...999_999))
        pin = newPIN
        pinIssuedAt = Date()
        state = .waitingForConfirmation
        await postPINNotification(newPIN, settings: settings)
    }

    func cancel() {
        pin = nil
        pinIssuedAt = nil
        state = .idle
        UNUserNotificationCenter.current().removeDeliveredNotifications(withIdentifiers: [notificationIdentifier])
        UNUserNotificationCenter.current().removePendingNotificationRequests(withIdentifiers: [notificationIdentifier])
    }

    /// Called only by the real authenticated transport after pair-verify and
    /// the required service handshake have completed successfully.
    func markTransportReady() {
        guard isPINCurrent else { return }
        state = .ready
    }

    func markTransportFailed(_ message: String) {
        state = .failed(message)
    }

    private var isPINCurrent: Bool {
        guard let pinIssuedAt else { return false }
        return Date().timeIntervalSince(pinIssuedAt) < pinLifetime
    }

    private func requestNotificationPermissionIfNeeded() async -> UNNotificationSettings {
        let center = UNUserNotificationCenter.current()
        let current = await center.notificationSettings()
        guard current.authorizationStatus == .notDetermined else { return current }
        _ = try? await center.requestAuthorization(options: [.alert, .sound, .badge])
        return await center.notificationSettings()
    }

    private func postPINNotification(_ pin: String, settings: UNNotificationSettings) async {
        guard settings.authorizationStatus == .authorized || settings.authorizationStatus == .provisional else {
            return
        }

        let content = UNMutableNotificationContent()
        content.title = "3105 AirLift Pairing"
        content.body = "Código de pareamento: \(pin)"
        content.sound = .default
        content.userInfo = ["type": "airlift-pairing", "pin": pin]

        let request = UNNotificationRequest(
            identifier: notificationIdentifier,
            content: content,
            trigger: nil
        )
        try? await UNUserNotificationCenter.current().add(request)
    }
}
